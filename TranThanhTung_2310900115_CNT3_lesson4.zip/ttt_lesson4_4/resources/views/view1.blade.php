<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo view đơn giản</title>
</head>
<body>
    <h1>Tạo view đơn giản </h1>
    <hr>
    <h2>Hiển thị ngôn ngữ ứng dung blade: {{$name}}</h2>
</body>
</html>