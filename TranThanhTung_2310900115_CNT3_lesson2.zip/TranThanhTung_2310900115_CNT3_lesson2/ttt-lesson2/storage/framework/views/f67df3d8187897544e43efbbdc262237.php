<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tung</title>
</head>
<body>
    <h1>welcome, Trần Thanh Tùng</h1>
</body>
</html><?php /**PATH E:\project 1\K23CNT3_TranThanhTung_Project1Lab\ttt-lesson2\resources\views/Tung.blade.php ENDPATH**/ ?>